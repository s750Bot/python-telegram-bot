# Examples

A description of the examples in this directory can be found in the [documentation](https://docs.python-telegram-bot.org/examples.html).

All examples are licensed under the [CC0 License](https://github.com/python-telegram-bot/python-telegram-bot/blob/master/examples/LICENSE.txt) and are therefore fully dedicated to the public domain. You can use them as the base for your own bots without worrying about copyrights.