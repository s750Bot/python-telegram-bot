BotCommandScopeChatAdministrators
=================================

.. autoclass:: telegram.BotCommandScopeChatAdministrators
    :members:
    :show-inheritance: