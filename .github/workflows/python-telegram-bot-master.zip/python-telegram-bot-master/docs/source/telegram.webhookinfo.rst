WebhookInfo
===========

.. autoclass:: telegram.WebhookInfo
    :members:
    :show-inheritance:
