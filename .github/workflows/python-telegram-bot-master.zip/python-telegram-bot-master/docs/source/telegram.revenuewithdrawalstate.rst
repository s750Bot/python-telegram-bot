RevenueWithdrawalState
======================

.. autoclass:: telegram.RevenueWithdrawalState
    :members:
    :show-inheritance:
    :inherited-members: TelegramObject
