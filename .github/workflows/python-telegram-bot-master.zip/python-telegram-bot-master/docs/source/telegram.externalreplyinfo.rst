ExternalReplyInfo
=================

.. autoclass:: telegram.ExternalReplyInfo
    :members:
    :show-inheritance:
