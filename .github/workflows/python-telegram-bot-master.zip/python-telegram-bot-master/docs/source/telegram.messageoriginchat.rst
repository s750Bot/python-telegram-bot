MessageOriginChat
=================

.. autoclass:: telegram.MessageOriginChat
    :members:
    :show-inheritance:
