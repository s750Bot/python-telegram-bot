BaseHandler
===========

.. autoclass:: telegram.ext.BaseHandler
    :members:
    :show-inheritance:
