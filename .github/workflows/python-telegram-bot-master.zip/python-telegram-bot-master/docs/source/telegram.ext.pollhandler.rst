PollHandler
===========

.. autoclass:: telegram.ext.PollHandler
    :members:
    :show-inheritance:
