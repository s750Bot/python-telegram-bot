InputLocationMessageContent
===========================

.. autoclass:: telegram.InputLocationMessageContent
    :members:
    :show-inheritance:
