ChatJoinRequestHandler
======================

.. autoclass:: telegram.ext.ChatJoinRequestHandler
    :members:
    :show-inheritance:
