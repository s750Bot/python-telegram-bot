``conversationbot2.py``
=======================

.. literalinclude:: ../../examples/conversationbot2.py
   :language: python
   :linenos:

.. _conversationbot2-diagram:

State Diagram
-------------

.. mermaid:: ../../examples/conversationbot2.mmd
