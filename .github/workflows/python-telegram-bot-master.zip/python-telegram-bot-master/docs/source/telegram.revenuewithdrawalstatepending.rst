RevenueWithdrawalStatePending
=============================

.. autoclass:: telegram.RevenueWithdrawalStatePending
    :members:
    :show-inheritance:
    :inherited-members: TelegramObject
