SecureValue
===========

.. autoclass:: telegram.SecureValue
    :members:
    :show-inheritance:
