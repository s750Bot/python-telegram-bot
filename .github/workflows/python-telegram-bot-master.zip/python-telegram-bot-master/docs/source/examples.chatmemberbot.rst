``chatmemberbot.py``
====================

.. literalinclude:: ../../examples/chatmemberbot.py
   :language: python
   :linenos:
    