Credentials
===========

.. autoclass:: telegram.Credentials
    :members:
    :show-inheritance:
