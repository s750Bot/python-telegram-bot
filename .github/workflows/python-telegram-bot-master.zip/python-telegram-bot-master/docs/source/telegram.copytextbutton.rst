CopyTextButton
==============

.. autoclass:: telegram.CopyTextButton
    :members:
    :show-inheritance: