ChatBoostAdded
==============

.. autoclass:: telegram.ChatBoostAdded
    :members:
    :show-inheritance: