MenuButtonDefault
=================

.. autoclass:: telegram.MenuButtonDefault
    :members:
    :show-inheritance: