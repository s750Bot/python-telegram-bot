TransactionPartnerFragment
==========================

.. autoclass:: telegram.TransactionPartnerFragment
    :members:
    :show-inheritance:
    :inherited-members: TransactionPartner
