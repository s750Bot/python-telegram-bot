InputPaidMediaVideo
===================

.. autoclass:: telegram.InputPaidMediaVideo
    :members:
    :show-inheritance: