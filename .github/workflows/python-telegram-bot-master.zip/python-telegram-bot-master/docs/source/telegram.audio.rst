Audio
=====

.. Also lists methods of _BaseThumbedMedium, but not the ones of TelegramObject

.. autoclass:: telegram.Audio
    :members:
    :show-inheritance:
    :inherited-members: TelegramObject
