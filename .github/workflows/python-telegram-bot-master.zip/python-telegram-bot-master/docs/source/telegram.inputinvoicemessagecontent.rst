InputInvoiceMessageContent
==========================

.. autoclass:: telegram.InputInvoiceMessageContent
    :members:
    :show-inheritance:
