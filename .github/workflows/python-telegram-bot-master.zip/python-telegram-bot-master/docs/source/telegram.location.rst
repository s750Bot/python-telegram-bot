Location
========

.. autoclass:: telegram.Location
    :members:
    :show-inheritance:
