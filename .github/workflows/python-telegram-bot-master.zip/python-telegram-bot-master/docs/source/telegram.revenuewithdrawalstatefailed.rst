RevenueWithdrawalStateFailed
=============================

.. autoclass:: telegram.RevenueWithdrawalStateFailed
    :members:
    :show-inheritance:
    :inherited-members: TelegramObject
