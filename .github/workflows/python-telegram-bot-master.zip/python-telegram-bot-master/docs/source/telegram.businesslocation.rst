BusinessLocation
==================

.. autoclass:: telegram.BusinessLocation
    :members:
    :show-inheritance: