RevenueWithdrawalStateSucceeded
===============================

.. autoclass:: telegram.RevenueWithdrawalStateSucceeded
    :members:
    :show-inheritance:
    :inherited-members: TelegramObject
