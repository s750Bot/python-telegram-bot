MenuButtonCommands
==================

.. autoclass:: telegram.MenuButtonCommands
    :members:
    :show-inheritance: