BotName
=======

.. autoclass:: telegram.BotName
    :members:
    :show-inheritance: