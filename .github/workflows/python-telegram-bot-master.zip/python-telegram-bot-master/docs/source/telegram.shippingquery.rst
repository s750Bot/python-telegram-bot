ShippingQuery
=============

.. autoclass:: telegram.ShippingQuery
    :members:
    :show-inheritance:
