PassportElementError
====================

.. autoclass:: telegram.PassportElementError
    :members:
    :show-inheritance:
